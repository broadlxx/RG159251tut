package templatesTutorial;

public enum Gender {
	MALE,FEMALE
}
