# assignment1

## members: Lv XueXiang（19023249） and Wang Chang（19023257）

We wrote most of the Notepad functions in Text_editor. Java and used them like Select text, Copy, Paste , Cut,print,PDF etc.
There are separate functions in the print, open, save and search function 
The first step in text_editor. Java is to listen to each button and implement its functionality after the establishment of the text box. 

We completed different syntax should be shown in different colour in highlight. Java 

In the test file, we tested the common functions of open ,save and search. 

In report file ,there is metrics and PMD.

we finished the Travis_CI.

### We used json to get the members of our group.
You can find we use the *.json in the Text_editor.java in the last ,when you click the "Member" .The json2.java is get the information in the config.json then in the json.java we analysis the information from the *.json and use this in the Text_editor.java

If you have some questions , please contact authors at 1049649381@qq.com or 854469796@qq.com
