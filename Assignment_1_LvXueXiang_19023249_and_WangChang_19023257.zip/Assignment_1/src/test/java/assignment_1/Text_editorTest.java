package assignment_1;

import java.util.*;
import java.util.List;
import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class Text_editorTest 




    extends TestCase
{
    @SuppressWarnings("unused")
	private FileWriter fileWriter_testsave;

	/**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public Text_editorTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested////////////////
     */
    public static Test suite()
    {
        return new TestSuite( Text_editorTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testopen() throws FileNotFoundException
    {
    	Text_editor texteditor_testopen = new Text_editor();
		File testopen = new File("testopen.txt");
		String addresstest = testopen.getAbsolutePath(); 
		texteditor_testopen.open(addresstest);
		
		FileReader fileReader = new FileReader(addresstest);
		BufferedReader bufferedReader = new BufferedReader(fileReader);		
		String str = "";			
		String strAll = "";		
		try {
			while((str = bufferedReader.readLine()) != null)	
			{					
				strAll += str + "\r\n";		
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(texteditor_testopen.jTextPane.getText(),strAll);
    }
    
    public void testsave() throws IOException {
    	
    	Text_editor texteditor_testsave = new Text_editor();
    	File testsave = new File("testsave.txt");
    	texteditor_testsave.jTextPane.setText("bbbbcccccdddd");
    	String addresstest = testsave.getAbsolutePath(); 
    	texteditor_testsave.save(addresstest);
    	
//    	System.out.println(texteditor_testsave.jTextArea.getText());
    	
    	texteditor_testsave.open(addresstest);
    	
    	String str = "";			
		String strAll = "";	
		try {
			FileReader fileReader = new FileReader(addresstest);
			@SuppressWarnings("resource")
			BufferedReader bufferedReaders = new BufferedReader(fileReader);	
			while((str = bufferedReaders.readLine()) != null)	
			{					
				strAll += str + "\r\n";		
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		System.out.println(strAll);
    	assertEquals(texteditor_testsave.jTextPane.getText(),strAll);
//    	
    	
    }

    public void testsearch() throws IOException {

    	Text_editor texteditor_testsearch = new Text_editor();
    	File testsearch = new File("testsearch.txt");
    	texteditor_testsearch.jTextPane.setText("abcd\nefgh\nijkl\nmnco");
    	String addresstest = testsearch.getAbsolutePath(); 
    	texteditor_testsearch.save(addresstest);
    	texteditor_testsearch.findText.setText("c");
    	texteditor_testsearch.search(texteditor_testsearch.findText,texteditor_testsearch.findText.getText());  	
    	 List<String> si=new ArrayList<String>();
    	for(int i=-1; i<=texteditor_testsearch.jTextPane.getText().lastIndexOf(texteditor_testsearch.findText.getText());++i)
	    	{	
		    	i=texteditor_testsearch.jTextPane.getText().indexOf("c",i);
		    	si.add(Integer.toString(i));
	    	} 
    	for(String k:si) {
    		assertEquals(texteditor_testsearch.findText.getText(),texteditor_testsearch.jTextPane.getText().substring(Integer.valueOf(k).intValue(),Integer.valueOf(k).intValue()+1));
    	}
	}
}

