package assignment_1;

import com.alibaba.fastjson.JSON;

public class json {  //use for json configuration file
//    public static json2  JS = new json2();
	
	public static String memberstring(){   	 
	        String s = json2.readJsonFile("config.json");
	        com.alibaba.fastjson.JSONObject jobj = JSON.parseObject(s);
	        java.lang.String member = (String)jobj.get("name");
	       				return member;
	        }
	public static String datestring(){    
        String s = json2.readJsonFile("config.json");
        com.alibaba.fastjson.JSONObject jobj = JSON.parseObject(s);
        java.lang.String date = (String)jobj.get("Date");
       				return date;
        }    
    }