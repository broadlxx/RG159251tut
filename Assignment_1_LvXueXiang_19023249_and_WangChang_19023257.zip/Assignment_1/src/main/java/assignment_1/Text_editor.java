package assignment_1;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.ServiceUI;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;


//javax.swing.text.JTextComponent;
//让其继承窗口类
public class Text_editor extends JFrame implements ActionListener { 	
	/**	 * 	 */	
	private static final long serialVersionUID = 1L;
	
	
	//定义一个文本框	
	JTextArea jTextArea = null;	
	JTextPane jTextPane = null;
	
	JMenuBar jMenuBar = null;	
	JMenu jMenu1 = null;	
	JMenuItem jMenuItem0 = null;	
	JMenuItem jMenuItem1 = null;	
	JMenuItem jMenuItem2 = null;
	JMenuItem jMenuItem3 = null;
	JMenuItem jMenuItem4 = null;
	
	JMenu jMenu2 = null;
	JMenuItem jMenuItem20 = null;
	
	JMenu jMenu3 = null;
	JMenuItem jMenuItem30 = null;	
	JMenuItem jMenuItem31 = null;	
	JMenuItem jMenuItem32 = null;
	JMenuItem jMenuItem33 = null;
	JMenuItem jMenuItem34 = null;
	
	JMenu jMenu4 = null;
	JMenuItem jMenuItem40 = null;
//	JMenuItem jMenuItem41 = null;
	
	JMenu jMenu5 = null;
	JMenuItem jMenuItem50 = null;
	
	//Define a file selection 
	JFileChooser jFileChooser = null;	
	//Define a FileReader file input stream 	
	FileReader fileReader = null;	
	//Define a FileWriter output stream 	
	FileWriter fileWriter = null;	
	//Define a buffer character input stream	
	BufferedReader bufferedReader = null;	
	//Define a buffer character output stream 	
	BufferedWriter bufferedWriter = null;


	public final JTextField findText=new JTextField(15);
	
	@SuppressWarnings("unused")	
	public static void main(String[] args) {		
		// TODO Auto-generated method stub        
		//实例化		
		Text_editor notePal = new Text_editor();	}	
	//构造函数	
	public Text_editor()	{		
		//Instantiate jTextArea 		
//		jTextArea = new JTextArea();
		jTextPane = new JTextPane();
		
//		JScrollPane sp = new JScrollPane(jTextPane);
//		jTextPane.add(jTextPane);
	    JScrollPane jscroll = new JScrollPane(jTextPane);
		
//	    jTextPane.add(jscroll);	  
	    
	    jscroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    jscroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
	    jTextPane.setBounds(0, 30, 900, 600);
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(jTextPane,BorderLayout.CENTER);
		
		this.getContentPane().add(panel);
        JScrollPane scroll = new JScrollPane(jTextPane);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		panel.add(scroll,BorderLayout.CENTER);
	    
	    
		//Instantiate jMenuBar		
		jMenuBar = new JMenuBar();		
		//Instantiate jMenu1 and set its name to "File" 	
		jMenu1 = new JMenu("File");		
		jMenuItem0 = new JMenuItem("New");		
		jMenuItem0.addActionListener(this);		
		jMenuItem0.setActionCommand("New");		
		jMenuItem1 = new JMenuItem("Open");		
		jMenuItem1.addActionListener(this);		
		jMenuItem1.setActionCommand("Open");			
		jMenuItem2 = new JMenuItem("Save");		
		jMenuItem2.addActionListener(this);	
		jMenuItem2.setActionCommand("Save");
		jMenuItem3 = new JMenuItem("Print");		
		jMenuItem3.addActionListener(this);	
		jMenuItem3.setActionCommand("Print");
		jMenuItem4 = new JMenuItem("Exit");		
		jMenuItem4.addActionListener(this);	
		jMenuItem4.setActionCommand("Exit");
		
		jMenu2 = new JMenu("SearchFunction");
		jMenuItem20 = new JMenuItem("Search");		
		jMenuItem20.addActionListener(this);	
		jMenuItem20.setActionCommand("Search");	
		
		jMenu3 = new JMenu("View");		
		jMenuItem30 = new JMenuItem("Select text");		
		jMenuItem30.addActionListener(this);		
		jMenuItem30.setActionCommand("Select text");		
		jMenuItem31 = new JMenuItem("Copy");		
		jMenuItem31.addActionListener(this);		
		jMenuItem31.setActionCommand("Copy");			
		jMenuItem32 = new JMenuItem("Paste");		
		jMenuItem32.addActionListener(this);	
		jMenuItem32.setActionCommand("Paste");			
		jMenuItem33 = new JMenuItem("Cut");		
		jMenuItem33.addActionListener(this);	
		jMenuItem33.setActionCommand("Cut");
		jMenuItem34 = new JMenuItem("Time and Date (T&D)");		
		jMenuItem34.addActionListener(this);	
		jMenuItem34.setActionCommand("Time and Date (T&D)");
		
		jMenu4 = new JMenu("Manage");
//		jMenuItem40 = new JMenuItem("Print");		
//		jMenuItem40.addActionListener(this);	
//		jMenuItem40.setActionCommand("Print");
		jMenuItem40 = new JMenuItem("PDF");		
		jMenuItem40.addActionListener(this);	
		jMenuItem40.setActionCommand("PDF");
		
		jMenu5 = new JMenu("Help");
		jMenuItem50 = new JMenuItem("Member");		
		jMenuItem50.addActionListener(this);	
		jMenuItem50.setActionCommand("Member");
			
		//Add components to their respective locations 	
		this.setJMenuBar(jMenuBar);	
		//Add jMenu to jMenuBar 	
		jMenuBar.add(jMenu1);	
		jMenu1.add(jMenuItem0);	
		jMenu1.add(jMenuItem1);	
		jMenu1.add(jMenuItem2);		
		jMenu1.add(jMenuItem3);
		jMenu1.add(jMenuItem4);
		
		jMenuBar.add(jMenu2);
		jMenu2.add(jMenuItem20);
		
		jMenuBar.add(jMenu3);	
		jMenu3.add(jMenuItem30);	
		jMenu3.add(jMenuItem31);	
		jMenu3.add(jMenuItem32);		
		jMenu3.add(jMenuItem33);
		jMenu3.add(jMenuItem34);
		
		jMenuBar.add(jMenu4);			
//		jMenu4.add(jMenuItem40);
		jMenu4.add(jMenuItem40);
		
		jMenuBar.add(jMenu5);
		jMenu5.add(jMenuItem50);
		
//		JTextPane editor = new JTextPane();
		jTextPane.getDocument().addDocumentListener(new SyntaxHighlighter(jTextPane));
//		this.getContentPane().add(jTextPane,BorderLayout.NORTH);
		
		
		//Set the title of the form 		
		this.setTitle("Text editor");	
		//Set the size of the form 	
		this.setSize(800,600);	
		//When closing a window, close the process 		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		//	Display window 	
		this.setVisible(true);	
//		
//		
		jTextPane.add(jscroll, BorderLayout.CENTER);
//        add(jTextPane);
		
		
	}	
	
	public void open(String address) {
			
		try {			
			//Allocate space for fileReader 
			fileReader = new FileReader(address);		
			//Allocate space for BufferedReader 		
			bufferedReader = new BufferedReader(fileReader);	
			//Define a str to determine whether the input character is empty 		
			String str = "";		
			//Define all the information of a strAll receiving file 		
			String strAll = "";		
			//Read the file information and save it in strAll 
			while((str = bufferedReader.readLine()) != null)	
			{					
				strAll += str + "\r\n";		
			}				
			//Display all information in strAll on JTextArea 		
			jTextPane.setText(strAll);		
		} catch (Exception e2) {			
			// TODO: handle exception			
			e2.printStackTrace();		
		}
	}
	
	public void save(String address){
		try {
			//Allocate space for fileWrite 		
			fileWriter = new FileWriter(address);
			//Allocate space for bufferedWrite 	
			bufferedWriter = new BufferedWriter(fileWriter);		
			//Save in 
//			System.out.println(this.jTextArea.getText());
			bufferedWriter.write(this.jTextPane.getText());	
			bufferedWriter.close();		
			fileWriter.close();
		} catch (Exception e2) {		
			// TODO: handle exception		
			e2.printStackTrace();	
		}	
	}
	
	public void print() {
		JFileChooser fileChooser = new JFileChooser(); // Create a print job 
         int state = fileChooser.showOpenDialog(null);
         if (state == fileChooser.APPROVE_OPTION) {       	 
             File file = fileChooser.getSelectedFile(); // Get the selected file 
             // Constructing Print Request Attribute Set 
             HashPrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
             // Set print format, select UTF-8
             DocFlavor flavor = DocFlavor.INPUT_STREAM.TEXT_HTML_UTF_8;
             // Find all available print services 
             PrintService printService[] = PrintServiceLookup.lookupPrintServices(flavor, pras);
             //Locate the default print service  
             PrintService defaultService = PrintServiceLookup
                     .lookupDefaultPrintService();
             //Display Print Dialog Box  
             PrintService service = ServiceUI.printDialog(null, 200, 200,
                     printService, defaultService, flavor, pras);
             if (service != null) {
                 try {
                     DocPrintJob job = service.createPrintJob(); // Create a print job 
                     FileInputStream fis = new FileInputStream(file); // Construct the file stream to be printed 
                     DocAttributeSet das = new HashDocAttributeSet();
                     Doc doc = new SimpleDoc(fis, flavor, das);
                     job.print(doc, pras);
                 } catch (Exception e) {
                     e.printStackTrace();
                 }
             }
         }
     }
	
	public void search(final JTextField findText,final String string) { 
		final JDialog findDialog=new JDialog(this,"search",false);//False allows other windows to be activated at the same time (i.e., no mode) 
        Container con=findDialog.getContentPane();// Returns the contentPane object of this dialog box   
        con.setLayout(new FlowLayout(FlowLayout.LEFT));  
        JLabel findContentLabel=new JLabel("Search content:");  
   
        JButton findNextButton=new JButton("next：");  
        final JCheckBox matchCheckBox=new JCheckBox("Case-sensitive ");  
        ButtonGroup bGroup=new ButtonGroup();  
        final JRadioButton upButton=new JRadioButton("up");  
        final JRadioButton downButton=new JRadioButton("down");  
        downButton.setSelected(true);  
        bGroup.add(upButton);  
        bGroup.add(downButton);  
        JButton cancel=new JButton("cancel");  
        // Cancel button event handling 
        cancel.addActionListener(new ActionListener()  
        {   public void actionPerformed(ActionEvent e)  
            {   findDialog.dispose();  
            }  
        });  
        //  Find Next button listening 
        findNextButton.addActionListener(new ActionListener()  
        {   public void actionPerformed(ActionEvent e)  
            {   // Is the case-sensitive JCheckBox selected 
                int k=0,m=0;  
                final String str1,str2,str3,str4,strA,strB;  
                str1=jTextPane.getText();
                str1.replaceAll("\r", "");
                str2=findText.getText();  
                str3=str1.toUpperCase();  
                str4=str2.toUpperCase(); 
                System.out.println(jTextPane.getText());
                if(matchCheckBox.isSelected())//Case-sensitive   
                {   strA=str1;  
                    strB=str2;  
                }  
                else// It is case-insensitive. At this point, all the selected contents are capitalized (or lowercase) for easy searching. 
                {   strA=str3;  
                    strB=str4;  
                }  
                if(upButton.isSelected())  
                {   //k=strA.lastIndexOf(strB,editArea.getCaretPosition()-1);  
                    if(jTextPane.getSelectedText()==null)  
                        k=strA.lastIndexOf(strB,jTextPane.getCaretPosition()-1);  
                    else  
                        k=strA.lastIndexOf(strB,jTextPane.getCaretPosition()-findText.getText().length()-1);      
                    if(k>-1)  
                    {   
//                    	//String strData=strA.subString(k,strB.getText().length()+1);  
                    	jTextPane.setCaretPosition(k);  
                    	jTextPane.select(k,k+strB.length());  
                    }  
                    else  
                    {   JOptionPane.showMessageDialog(null,"You can't find what you're looking for.！","search",JOptionPane.INFORMATION_MESSAGE);  
                    }  
                }  
                else if(downButton.isSelected())  
                {   if(jTextPane.getSelectedText()==null)  {
                	k=strA.indexOf(strB,jTextPane.getCaretPosition()+1); 
                	System.out.println(k+" 1");
                }
                         
                    else  {
                        k=strA.indexOf(strB, jTextPane.getCaretPosition()-findText.getText().length()+1); }
                    if(k>-1)  
                    {   //String strData=strA.subString(k,strB.getText().length()+1);  
                    	jTextPane.setCaretPosition(k);  
                    	jTextPane.select(k,k+strB.length()); 

                    }  
                    else  
                    {   JOptionPane.showMessageDialog(null,"You can't find what you're looking for.","search",JOptionPane.INFORMATION_MESSAGE);  
                    }  
                }  
            }  
        });// Find Next Button Ends Listening 
        // Create an interface for the Find dialog box 
        JPanel panel1=new JPanel();  
        JPanel panel2=new JPanel();  
        JPanel panel3=new JPanel();  
        JPanel directionPanel=new JPanel();  
        directionPanel.setBorder(BorderFactory.createTitledBorder("direction"));  
        // Set the border of the directionPanel component; 
        
        // BorderFactory. createTitledBorder (String title) creates a new title border, 
        //uses the default border (embossed), default text location (on the top line), default adjustment (leading), 
        //and default font and text color determined by the current appearance, and specifies the title text.
        directionPanel.add(upButton);  
        directionPanel.add(downButton);  
        panel1.setLayout(new GridLayout(2,1));  
        panel1.add(findNextButton);  
        panel1.add(cancel);  
        panel2.add(findContentLabel);  
        panel2.add(findText);  
        panel2.add(panel1);  
        panel3.add(matchCheckBox);  
        panel3.add(directionPanel);  
        con.add(panel2);  
        con.add(panel3);  
        findDialog.setSize(410,180);  
        findDialog.setResizable(false);
        
        findDialog.setLocation(230,280);  
        findDialog.setVisible(true);  
    }
	
	public void actionPerformed(ActionEvent e) {		
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("New")){
			if(jTextPane.getText().equals("")) {
				jTextPane.setText("");
			}else {
				//	Create a save window 
				JFileChooser jFileChooser1 = new JFileChooser();	
				//Set the window name 		
				jFileChooser1.setDialogTitle("Save... ...");	
				//Setting default settings		
				int result = jFileChooser1.showSaveDialog(null);	
				//Display window 		
				jFileChooser1.setVisible(true);	
				String address = jFileChooser1.getSelectedFile().getAbsolutePath();
				if(result == JFileChooser.APPROVE_OPTION)
				{
				   String addressnew = jFileChooser1.getSelectedFile().getAbsolutePath();
				   save(addressnew);
				}
				else
				{
				    System.out.println("You have cancelled and closed the window. ！");
				   }	
				try {			
					bufferedWriter.close();		
					fileWriter.close();	
					jTextPane.setText("");
				} catch (Exception e3) {		
						// TODO: handle exception			
					e3.printStackTrace();		
					}
			}
			
		}
		if(e.getActionCommand().equals("Open"))
		{			
			//Instantiate a JFileChoose 
			jFileChooser = new JFileChooser();		
			//Set the name of the file selection window 		
			jFileChooser.setDialogTitle("");		
			//Set the default path of the file window 		
			jFileChooser.showOpenDialog(null);	
			//	Display File Window 
			jFileChooser.setVisible(true);	
			//Save the absolute path of user edited files with address 
			String address = jFileChooser.getSelectedFile().getAbsolutePath();
			open(address);
			try {			
				//close file		
				bufferedReader.close();		
				fileReader.close();			
			} catch (Exception e3) {			
				// TODO: handle exception		
				e3.printStackTrace();			
				}	
		}		
		//If the user clicks on the Save button 
		if(e.getActionCommand().equals("Save"))	
		{	
			//Create a save window 		
			JFileChooser jFileChooser1 = new JFileChooser();	
			//Set the window name 		
			jFileChooser1.setDialogTitle("Save... ...");	
			//Setting default settings		
			int result = jFileChooser1.showSaveDialog(null);	
			//display windows			
			jFileChooser1.setVisible(true);	
			
			if(result == JFileChooser.APPROVE_OPTION)
			{
			   String address = jFileChooser1.getSelectedFile().getAbsolutePath();
			   save(address);
			}
			else
			{
			    System.out.println("你已取消并关闭了窗口！");
			   }
		}	
		
		if(e.getActionCommand().equals("Search")) {		
			String str = findText.getText();
			search(findText,str);
       }

		
		if(e.getActionCommand().equals("Exit"))	{
			System.exit(0);
		}
		if(e.getActionCommand().equals("Select text")) {
			jTextPane.selectAll();
		}
		if(e.getActionCommand().equals("Copy")) {
			jTextPane.copy();
		}
		if(e.getActionCommand().equals("Paste")) {
			jTextPane.paste();
		}
		if(e.getActionCommand().equals("Cut")) {
			jTextPane.cut();
		}
		
		if(e.getActionCommand().equals("Time and Date (T&D)")) {
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        String date = sdf.format(new Date());
	        jTextPane.replaceSelection(date.toString());
		}
		if(e.getActionCommand().equals("Print")) {
			try {
				jTextPane.print();
			} catch (PrinterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		if(e.getActionCommand().equals("PDF")) {	
			JFileChooser jFileChooserPDF = new JFileChooser();		
			FileNameExtensionFilter filter = new FileNameExtensionFilter("PDF文件(*.pdf)", "pdf");
			jFileChooserPDF.setFileFilter(filter);	
			//jFileChooserPDF.showSaveDialog(null);					
			jFileChooserPDF.setVisible(true);
			int option = jFileChooserPDF.showSaveDialog(null);	
			if(option==JFileChooser.APPROVE_OPTION){	
				//If the user chooses to save 		
				File file = jFileChooserPDF.getSelectedFile();		
				String fname = jFileChooserPDF.getName(file);	
				//Get the filename from the filename input box and add a suffix to it 
				file=new File(jFileChooserPDF.getCurrentDirectory(),fname+".pdf");
				try {		
					FileOutputStream fileoutput = new FileOutputStream(file);
					Document document = new Document();
					PdfWriter writer = PdfWriter.getInstance(document,fileoutput);
					document.open();
					document.add(new Paragraph(this.jTextPane.getText()));
					document.close();			
				} catch (IOException e2) {	
					System.err.println("IO Error");	
					e2.printStackTrace();	
					} catch (DocumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();;
					}		
			}
			}

		if(e.getActionCommand().equals("Member")) {
//			System.out.println(json.memberstring());
			//USing json print
			JOptionPane.showMessageDialog(Text_editor.this, json.memberstring()+"\n"+json.datestring());
		}
//		if(e.getActionCommand().equals("Member")) {
//			File file=new File("D:\\软工tutorial\\Assignment_1\\config.json");
//	        String content = null;
//			try {
//				content = FileUtils.readFileToString(file,"UTF-8");
//			} catch (IOException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
//	        JSONObject jsonObject=new JSONObject(content);
//			JOptionPane.showMessageDialog(Text_editor.this, jsonObject.getString("name"));
//			JOptionPane.showMessageDialog(Text_editor.this, jsonObject.getString("Date"));
//		}
		} 
}



