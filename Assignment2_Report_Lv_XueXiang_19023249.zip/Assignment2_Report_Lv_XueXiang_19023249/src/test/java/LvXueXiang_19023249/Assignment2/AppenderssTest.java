package LvXueXiang_19023249.Assignment2;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
/**
 * Unit test for simple App.
 */
public class AppenderssTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppenderssTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppenderssTest.class );
    }

    /**
     * Rigorous Test :-)
     */
    private VelocityLayout velocityLayout = new VelocityLayout();
    private Logger listlogger = Logger.getLogger("test.class");
    private MemAppender appendertest =  MemAppender.getSingleton();
    
    public void testApp()
    {
    	SimpleDateFormat testtime=new SimpleDateFormat("yyyy-MM-dd HH-mm-ss SSS"); 
    	listlogger.addAppender(appendertest);
	    appendertest.setMaxSize(6);
	    appendertest.setlayout(velocityLayout);
	    appendertest.setCurrantLogs(new ArrayList<LoggingEvent>());
	    
		LoggingEvent testevent1 = new LoggingEvent("thisCategory", listlogger, Level.DEBUG, "debug", null);
		LoggingEvent testevent2 = new LoggingEvent("thisCategory", listlogger, Level.DEBUG, "debug", null);
		LoggingEvent testevent3 = new LoggingEvent("thisCategory", listlogger, Level.INFO, "info", null);
		LoggingEvent testevent4 = new LoggingEvent("thisCategory", listlogger, Level.WARN, "warn", null);
		LoggingEvent testevent5 = new LoggingEvent("thisCategory", listlogger, Level.ERROR, "error", null);
		LoggingEvent testevent6 = new LoggingEvent("thisCategory", listlogger, Level.FATAL, "fatal", null);
		appendertest.append(testevent1);
		appendertest.append(testevent2);
		appendertest.append(testevent3);
		appendertest.append(testevent4);
		appendertest.append(testevent5);
		appendertest.append(testevent6);
	    
		
	    assertEquals(6, appendertest.getMaxSize());
	    assertEquals( appendertest.getCurrentLogs().get(0), testevent1);
	    assertEquals(0, appendertest.getdiscardcount());
	    
		assertEquals(velocityLayout, appendertest.getlayout());
		
		velocityLayout.setpattern("Category:$c Date:$d Message:$m Prioity:$p Thread:$t\n");
//		System.out.println(velocityLayout.InitVelocity(appendertest.getCurrentLogs().get(0)));
//		System.out.println("Category:"+appendertest.getCurrentLogs().get(0).getLoggerName()+" "+"Date:"+testtime.format(appendertest.getCurrentLogs().get(0).getTimeStamp())+" "+"Message:"+appendertest.getCurrentLogs().get(0).getMessage()+" "+"Prioity:"+appendertest.getCurrentLogs().get(0).getLevel()+" "+"Thread:"+appendertest.getCurrentLogs().get(0).getThreadName()+"\n");
		assertEquals(velocityLayout.format(appendertest.getCurrentLogs().get(0)),"Category:"+appendertest.getCurrentLogs().get(0).getLoggerName()+" "+"Date:"+testtime.format(appendertest.getCurrentLogs().get(0).getTimeStamp())+" "+"Message:"+appendertest.getCurrentLogs().get(0).getMessage()+" "+"Prioity:"+appendertest.getCurrentLogs().get(0).getLevel()+" "+"Thread:"+appendertest.getCurrentLogs().get(0).getThreadName()+"\n");
		
    }
}
