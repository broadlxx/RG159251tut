package LvXueXiang_19023249.Assignment2;

//import org.junit.jupiter.api.*;
//import org.junit.platform.runner.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.Before;
import org.junit.Test;
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;

//@RunWith(JUnitPlatform.class)
public class StressTest{
//	private Logger StressTestlogger = Logger.getLogger("stresstest.class");
//	private LinkedList<LoggingEvent> LinkedListlogs = new LinkedList<LoggingEvent>();
	private static MemAppender AppenderStressTest = MemAppender.getSingleton();
	
	@Before
	public void init() {
		AppenderStressTest = MemAppender.getSingleton();
		AppenderStressTest.setMaxSize(200000);
	}
	
	public void clearMemAppender() {
		AppenderStressTest.setCurrantLogs(null);
		AppenderStressTest.setLayout(null);
		AppenderStressTest.setdiscardcount(0);
		AppenderStressTest.close();
	}
	@Test
	public void testMemoryNotOverLinkedList() {	   
		Logger memoryNotOverLinkedListTestLogger = Logger.getLogger("MemoryNotOverLinkedList");
		memoryNotOverLinkedListTestLogger .addAppender(AppenderStressTest);
	    AppenderStressTest.setCurrantLogs(new LinkedList<LoggingEvent>());
//	    VelocityLayout ve = new VelocityLayout();   
//	    try {
//			memoryNotOverLinkedListTestLogger.addAppender(new FileAppender(ve, "src/test/resources/MemoryNotOverLinkedList.log"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    for (int i = 0; i < 150000; i++) {
	    	memoryNotOverLinkedListTestLogger.debug("debug");
		}
	    clearMemAppender();
	    }
	
	@Test
	public void testMemoryOverLinkedList() {	   
		Logger memoryOverLinkedListTestLogger = Logger.getLogger("MemoryOverLinkedList");
		memoryOverLinkedListTestLogger .addAppender(AppenderStressTest);
	    AppenderStressTest.setCurrantLogs(new LinkedList<LoggingEvent>());
//	    VelocityLayout ve = new VelocityLayout();   
//	    try {
//			memoryOverLinkedListTestLogger.addAppender(new FileAppender(ve, "src/test/resources/MemoryOverLinkedList.log"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    for (int i = 0; i < 500000; i++) {
	    	memoryOverLinkedListTestLogger.debug("debug");
		}
	    clearMemAppender();
	    }
	
	@Test
	public void testMemoryNotOverArrayList() {	   
		Logger memoryNotOverArrayListTestLogger = Logger.getLogger("MemoryNotOverArrayList");
		memoryNotOverArrayListTestLogger .addAppender(AppenderStressTest);
	    AppenderStressTest.setCurrantLogs(new ArrayList<LoggingEvent>());
//	    VelocityLayout ve = new VelocityLayout();   
//	    try {
//			memoryNotOverArrayListTestLogger.addAppender(new FileAppender(ve, "src/test/resources/MemoryNotOverArrayList.log"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    for (int i = 0; i < 150000; i++) {
	    	memoryNotOverArrayListTestLogger.debug("debug");
		}
	    clearMemAppender();
	    }
	
	@Test
	public void testMemoryOverArrayList() {	   
		Logger memoryOverArrayListTestLogger = Logger.getLogger("MemoryOverArrayList");
		memoryOverArrayListTestLogger .addAppender(AppenderStressTest);
	    AppenderStressTest.setCurrantLogs(new ArrayList<LoggingEvent>());
//	    VelocityLayout ve = new VelocityLayout();   
//	    try {
//			memoryOverArrayListTestLogger.addAppender(new FileAppender(ve, "src/test/resources/MemoryOverArrayList.log"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    for (int i = 0; i < 200000; i++) {
	    	memoryOverArrayListTestLogger.debug("debug");
		}
	    clearMemAppender();
	    }
	
	@Test
	public void testConsoleAppenderTest() {
		Logger ConsoleAppenderTestlogger = Logger.getLogger("ConsoleAppenderTest");		
		VelocityLayout vl = new VelocityLayout();
		System.out.println(vl.getpattern());
		ConsoleAppender consoleAppender = new ConsoleAppender(vl);
		ConsoleAppenderTestlogger.addAppender(consoleAppender);
		for (int i = 0; i < 150000; i++) {
			ConsoleAppenderTestlogger.debug("debug");;
		}
		clearMemAppender();
	}
	
	@Test
	/*
		Test MemAppender With ArrayList which is not over max size
	 */
	public void testFileAppenderTest() {
		Logger FileAppenderTest = Logger.getLogger("FileAppenderTest");
		VelocityLayout ve = new VelocityLayout();
		ve.setpattern("Category:$c Date:$d Message:$m Prioity:$p Thread:$t \n");
		try {
			FileAppenderTest.addAppender(new FileAppender(ve, "src/test/resources/FileAppenderTest.log"));
			for (int i = 0; i < 150000; i++) {
				FileAppenderTest.debug("debug");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		clearMemAppender();
	}
	
	@Test
	public void  testVelocityLayoutTest() {	  
	   Logger VelocityLayoutTestlogger = Logger.getLogger("VelocityLayoutTest");
	   VelocityLayoutTestlogger.addAppender(AppenderStressTest);
	   AppenderStressTest.setCurrantLogs(new ArrayList<LoggingEvent>());
	   VelocityLayout ve = new VelocityLayout();
	   AppenderStressTest.setlayout(ve);	
//	   try {
//		   VelocityLayoutTestlogger.addAppender(new FileAppender(ve, "src/test/resources/VelocityLayoutTest.log"));
//	   } catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//	   }
	   for (int i = 0; i < 150000; i++) {
		   VelocityLayoutTestlogger.debug("debug");
	   }
	   clearMemAppender();
	}
	
	@Test
	public void testPatternLayoutTest() {
		   Logger PatternLayoutTestlogger = Logger.getLogger("PatternLayoutTest");
		   PatternLayoutTestlogger.addAppender(AppenderStressTest);
		   AppenderStressTest.setCurrantLogs(new ArrayList<LoggingEvent>());
		   PatternLayout pa = new PatternLayout();
		   VelocityLayout ve = new VelocityLayout();
		   AppenderStressTest.setlayout(ve);	      
//		   try {
//			   PatternLayoutTestlogger.addAppender(new FileAppender(ve, "src/test/resources/PatternLayoutTest.log"));
//		   } catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//		   }
		   AppenderStressTest.setlayout(pa);
		   for (int i = 0; i < 150000; i++) {
			   PatternLayoutTestlogger.debug("debug");
		   }	   
		   clearMemAppender();
	}

}
