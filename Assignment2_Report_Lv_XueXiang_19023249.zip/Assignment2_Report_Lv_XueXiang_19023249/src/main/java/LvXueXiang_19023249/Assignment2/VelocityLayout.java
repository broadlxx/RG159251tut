package LvXueXiang_19023249.Assignment2;

import java.io.StringWriter;
import java.text.SimpleDateFormat;

import org.apache.log4j.PatternLayout;
import org.apache.log4j.spi.LoggingEvent;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;

public class VelocityLayout extends PatternLayout {
	SimpleDateFormat time=new SimpleDateFormat("yyyy-MM-dd HH-mm-ss SSS"); 
	private static String DEFAULTPATTERN  = "[Prioity:$p]   Category:$c   Date:$d :  Message:$m   Thread:$t \n";
	VelocityEngine velocity = new VelocityEngine();
	String pattern;	
	public String format(LoggingEvent event) {
		velocity.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		velocity.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
		velocity.init();	
		VelocityContext context = new VelocityContext();
		StringWriter EventStringWriter = new StringWriter();		
		context.put("c", event.getLoggerName());
		context.put("d", time.format(event.getTimeStamp()));
		context.put("m", (String) event.getMessage());
		context.put("p", event.getLevel().toString());
		context.put("t", event.getThreadName());
		context.put("n", System.lineSeparator());
		try {
			Velocity.evaluate(context, EventStringWriter,"layout", pattern);				
		}catch (Exception e) {
			e.printStackTrace();
		}	
//	System.out.println(sw.toString());
	return EventStringWriter.toString();		
	}
	
	public void setpattern(String pattern) {
		this.pattern = pattern;
	}
	public String getpattern() {
		return this.pattern;
	}
	public VelocityLayout() {
		this.pattern = DEFAULTPATTERN ;
	}
	public VelocityLayout(String pattern) {
		this.pattern = pattern;
	}

}
