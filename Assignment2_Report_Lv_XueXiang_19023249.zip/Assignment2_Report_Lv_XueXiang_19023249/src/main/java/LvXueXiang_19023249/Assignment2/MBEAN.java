package LvXueXiang_19023249.Assignment2;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;

public class MBEAN {
	public static void main(String[] args) throws Exception{   
		
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer(); 
        ObjectName name = new ObjectName("LvXueXiang_19023249.Assignment2.MemAppender:type=MBEAN,id=1"); 
        MemAppender mbean = MemAppender.getSingleton(); 
        mbs.registerMBean(mbean, name); 
	}
}
