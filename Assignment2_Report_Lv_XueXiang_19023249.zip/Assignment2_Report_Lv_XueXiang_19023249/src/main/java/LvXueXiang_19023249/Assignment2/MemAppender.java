package LvXueXiang_19023249.Assignment2;


import java.lang.management.ManagementFactory;
import java.util.*;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.spi.LoggingEvent;

public class MemAppender extends AppenderSkeleton {
	private static VelocityLayout ve = new VelocityLayout();
	private static MemAppender instance = new MemAppender();
	private MemAppender() {	
//		super();
//		MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
//		try {
//			ObjectName name = new ObjectName("LvXueXiang_19023249.Assignment2.MemAppender:type=MemAppender,id=1");
//			mBeanServer.registerMBean(this, name);
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
	}
	public static MemAppender getSingleton(){
	     return instance;
	  }

	public Layout layout;
	public LoggingEvent event;
	public int maxsize;
	public long discardcount;
	public String message;
	private String EventString;
	public static java.util.List<LoggingEvent> list;

	public void close() {
		// TODO Auto-generated method stub
		
	}

	public boolean requiresLayout() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void append(LoggingEvent event) {
		// TODO Auto-generated method stub
		this.event =event;	
//		System.out.println(list);
		if(list.size()<maxsize) {
			list.add(event);
		}
		else {
			discardcount = discardcount+1;
			list.remove(0);
			list.add(event);
		}
		getCurrentLogs();
//		System.out.println();
	}
	public void printlogs() {
		for(int e=0;e<list.size();e++) {
			System.out.println(e+1+":  "+format(list.get(e)));
//			if (true) {				
//				System.out.println(e+1+":  "+format(list.get(e)));
//			}else {
//				System.out.println(e+1+":  "+list.get(e));
//			}
		}
		list.clear();
		discardcount = 0;
	}
	public List<LoggingEvent> getCurrentLogs(){
		return Collections.unmodifiableList(MemAppender.list);
	}
	public void setCurrantLogs(List<LoggingEvent> linkedList){
		this.list = linkedList;
	}
	public List<LoggingEvent> getEventStrings(){
		ArrayList<String> list1 = new ArrayList<String>();
		for(int i=0;i<list.size();i++) {
			list1.add(list.get(i).toString());     
		}
		return Collections.unmodifiableList(MemAppender.list);
	}
	
	public String format(LoggingEvent event) {
		ve.setpattern("[Prioity:$p]   Category:$c  Date:$d :  Message:$m   Thread:$t $t $t \n");
		EventString = ve.format(event);
		return EventString;
	}	
	
	public int getMaxSize() {
		return maxsize;
	}
	public void setMaxSize(int maxsize) {
		this.maxsize = maxsize;
	}
	public long getdiscardcount() {
		return discardcount;
	}
	public void setdiscardcount(long discardcount) {
		this.discardcount = discardcount;
	}
	public void setlayout(Layout layout) {
		this.layout = layout;
	}
	public Layout getlayout() {
		return this.layout;
	}
	

}
