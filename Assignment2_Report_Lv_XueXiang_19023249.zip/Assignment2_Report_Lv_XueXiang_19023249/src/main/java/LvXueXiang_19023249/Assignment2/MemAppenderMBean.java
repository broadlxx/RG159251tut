package LvXueXiang_19023249.Assignment2;

import java.util.List;

import org.apache.log4j.spi.LoggingEvent;

public interface MemAppenderMBean {
	
//	public long getdiscardcount();
//	public void setdiscardcount(long discardcount);
//	
	public List<LoggingEvent> getCurrentLogs();
	public void setCurrantLogs(List<LoggingEvent> linkedList);
	public List<LoggingEvent> getEventStrings();	
	
	public int getMaxSize();
}
